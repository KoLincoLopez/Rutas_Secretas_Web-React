package com.example.microservicio_UsuariosRS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioUsuariosRsApplicationTests {

	@Test
	void contextLoads() {
	}

}
