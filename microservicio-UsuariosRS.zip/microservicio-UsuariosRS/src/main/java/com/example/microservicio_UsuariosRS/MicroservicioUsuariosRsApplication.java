package com.example.microservicio_UsuariosRS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioUsuariosRsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioUsuariosRsApplication.class, args);
	}

}
