package com.example.microservicio_CarritoRS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioCarritoRsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioCarritoRsApplication.class, args);
	}

}
