package com.example.microservicio_CarritoRS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioCarritoRsApplicationTests {

	@Test
	void contextLoads() {
	}

}
